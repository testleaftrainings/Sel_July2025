package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefintion extends BaseClass{
	
	
	@And("Enter the username as {string}")
	public void enter_the_username_as_demosalesmanager(String username) {
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
	}

	
	@And("Enter the password as {string}")
	public void enter_the_password_as_crmsfa(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	@When("Click on the Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should be able to login")
	public void it_should_be_able_to_login() {
	   System.out.println("Login successful");
	}
	
	
	
	@When("It throws error message")
	public void it_throws_error_message() {
	    System.out.println("It throws the error message");
	}

}
