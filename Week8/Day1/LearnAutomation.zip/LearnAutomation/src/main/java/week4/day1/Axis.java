package week4.day1;

public abstract class Axis implements RBI {

	//Implemented and unimplemented
	
	public void mandatoryKYC() {
		System.out.println("Driving license");
	}
	
	public void depositAmount() {
		System.out.println("10 Lakhs");
	}
	
	public abstract void houseLoan();
	
	
}
