package week4.day2;

import java.util.LinkedHashSet;
import java.util.Set;

public class LearnInegerSet {

	public static void main(String[] args) {

		// Declare an Integer Set
		Set<Integer> numbers = new LinkedHashSet<Integer>();
		numbers.add(1);

		//// Declare an Character Set
		Set<Character> letters = new LinkedHashSet<Character>();
		letters.add('V');

	}

}
