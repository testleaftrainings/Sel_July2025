package week4.day1;

public interface RBI {
	
	public void mandatoryKYC();
	
	public void depositAmount();

}
