package week1.day2;

public class LearnIfCondition {

	public static void main(String[] args) {
		int a = 20;
		int b = 20;

		if (a < b) {
			System.out.println("a is smaller than b");
		} else {
			System.out.println("a is greater than b");
		}

	}

}
