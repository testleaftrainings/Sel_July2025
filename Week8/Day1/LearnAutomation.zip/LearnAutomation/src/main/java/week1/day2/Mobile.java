package week1.day2;

public class Mobile {

	public void takePhoto() {
		System.out.println("Photo Taken");
	}

	public static void main(String[] args) {
		// ClassName objectName=new ClassName();
		Mobile cameraOptions = new Mobile();
		cameraOptions.takePhoto();
	}

}
