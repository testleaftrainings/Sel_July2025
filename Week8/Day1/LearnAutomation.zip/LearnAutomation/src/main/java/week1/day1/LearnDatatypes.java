package week1.day1;

public class LearnDatatypes {

	public static void main(String[] args) {

		// byte
		byte age = 31;
		System.out.println(age);

		// short
		short ageOfPerson = 128;

		// int
		int amount = 50000;

		// long
		long mobileNumber = 8925411170L;
		System.out.println(mobileNumber);

		// float
		float rupee = 1.123456789f;
		System.out.println(rupee);

		// double
		double dollar = 1.123456789;
		System.out.println(dollar);

		// char
		char logo = 'T';

		// boolean - true or false
		boolean haveBreakfast = false;

		// String
		String name = "Vineeth";

		// print 2 variables
		System.out.println(name + " " + age);

		// Print a String and variable- My name is Vineeth
		System.out.println("My name is " + name);

	}

}
