package week1.day2;

public class LearnStringMethods {

	public static void main(String[] args) {
	String name="vineeth";

	//toUpperCase - convert the string characters into Uppercase
	//input- vineeth
	//output-VINEETH - String
	
	String upper = name.toUpperCase();
	System.out.println(upper);
	
	System.out.println(name.toUpperCase());
	
	}

}
