package week1.day2;

public class Access2 {
	
	public static void main(String[] args) {
		Access1 accessOptions=new Access1();
		accessOptions.depositAmount();
		//accessOptions.w
	}

}
