package week3.day2;

public class ReverseString {

	public static void main(String[] args) {
		String str = "July";

		char[] charArray = str.toCharArray();

		for (int i = charArray.length - 1; i >= 0; i--) {
			System.out.println(charArray[i]);

		}
		System.out.println("----------------");
		// method2:

		for (int i = str.length() - 1; i >= 0; i--) {
			System.out.print(str.charAt(i));

		}
	}

}
