package week3.day2;

public class Vehicle {

	public void startDriving() {
		System.out.println("Driving started");

	}

	public static void main(String[] args) {
		Vehicle vehicleOptions = new Vehicle();
		vehicleOptions.startDriving();
	}

}
