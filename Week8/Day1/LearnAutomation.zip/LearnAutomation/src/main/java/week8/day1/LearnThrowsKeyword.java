package week8.day1;

public class LearnThrowsKeyword {

	public static void main(String[] args) throws InterruptedException, ArithmeticException  {
		Thread.sleep(3000);

	}

}
