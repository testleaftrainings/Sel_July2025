package week8.day1;

public class AccountDetails {

	private int number;

	
	public void get(int number) {
		this.number = number;

	}

	public int set() {

		return number;
	}

}
