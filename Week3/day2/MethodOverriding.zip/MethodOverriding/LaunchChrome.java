package week3.day2;

public class LaunchChrome {

	public void launchBrowser() {
		System.out.println("Chrome launched successfully");

	}

	public static void main(String[] args) {
		LaunchChrome chromeOptions = new LaunchChrome();
		chromeOptions.launchBrowser();

	}

}
