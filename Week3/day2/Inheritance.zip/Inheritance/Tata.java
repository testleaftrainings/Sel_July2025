package week3.day2;
//          Child extends Parent
public class Tata extends Car {
	
	public void applyHorn() {
		// TODO Auto-generated method stub

	}

}
